import tkinter as tk
from PIL import Image, ImageTk
import json

# Inicjalizacja głównego okna
root = tk.Tk()
root.title("Hit THE DOT!!!")

# Funkcje
def click():
    global points
    points += click_power
    update_display()

def buy_auto_clicker():
    global points, auto_clicker_cost, auto_clicker_power
    if points >= auto_clicker_cost:
        points -= auto_clicker_cost
        auto_clicker_power += 1
        auto_clicker_cost *= 2
        update_display()

def upgrade_click_power():
    global points, click_power, click_power_cost
    if points >= click_power_cost:
        points -= click_power_cost
        click_power += 1
        click_power_cost *= 2
        update_display()
        save_game()  # Zapisz stan gry po ulepszeniu

def auto_click():
    global points
    points += auto_clicker_power
    update_display()
    root.after(1000, auto_click)

def save_game():
    data = {
        'points': points,
        'click_power': click_power,
        'click_power_cost': click_power_cost,
        'auto_clicker_power': auto_clicker_power,
        'auto_clicker_cost': auto_clicker_cost,
        'dark_mode': dark_mode.get()
    }
    with open('game_data.json', 'w') as file:
        json.dump(data, file)

def load_game():
    global points, click_power, click_power_cost, auto_clicker_power, auto_clicker_cost
    try:
        with open('game_data.json', 'r') as file:
            data = json.load(file)
            points = data['points']
            click_power = data['click_power']
            click_power_cost = data.get('click_power_cost', 10)
            auto_clicker_power = data['auto_clicker_power']
            auto_clicker_cost = data['auto_clicker_cost']
            update_display()
            dark_mode.set(data.get('dark_mode', False))
            update_theme()
    except FileNotFoundError:
        pass

def update_display():
    points_label.config(text=f"Points: {points}")
    clicker_label.config(text=f"Click Power: {click_power}")
    auto_clicker_label.config(text=f"Auto Clicker Power: {auto_clicker_power}\nCost: {auto_clicker_cost}")
    upgrade_label.config(text=f"Upgrade Click Power\nCost: {click_power_cost}")

def update_theme():
    if dark_mode.get():
        root.configure(bg="#353640")
        points_label.config(bg="#353640", fg="white")
        click_button_frame.config(bg="#353640")
        click_button.config(bg="#353640", borderwidth=0)
        clicker_label.config(bg="#353640", fg="white")
        auto_clicker_label.config(bg="#353640", fg="white")
        buy_auto_clicker_button.config(bg="#353640")
        upgrade_button.config(bg="#353640")
        save_button.config(bg="#353640")
        load_button.config(bg="#353640")
        # Ustawienie koloru tła dla trybu ciemnego
        upgrade_label.config(bg="#353640")
    else:
        root.configure(bg="#f0f0f0")
        points_label.config(bg="#f0f0f0", fg="black")
        click_button_frame.config(bg="#f0f0f0")
        click_button.config(bg="#f0f0f0", borderwidth=0)
        clicker_label.config(bg="#f0f0f0", fg="black")
        auto_clicker_label.config(bg="#f0f0f0", fg="black")
        buy_auto_clicker_button.config(bg="#f0f0f0")
        upgrade_button.config(bg="#f0f0f0")
        save_button.config(bg="#f0f0f0")
        load_button.config(bg="#f0f0f0")
        # Ustawienie koloru tła dla trybu jasnego
        upgrade_label.config(bg="#f0f0f0")

def open_settings_window():
    settings_window = tk.Toplevel(root)
    settings_window.title("Settings")

    dark_mode_checkbox = tk.Checkbutton(settings_window, text="Dark Mode", variable=dark_mode, command=update_theme, font=("Arial", 14))
    dark_mode_checkbox.pack(padx=10, pady=10, anchor="e")

# Zmienne
points = 0
click_power = 1
click_power_cost = 10
auto_clicker_power = 1
auto_clicker_cost = 10

# Tryb ciemny (dark mode) / jasny (light mode)
dark_mode = tk.BooleanVar()
dark_mode.set(False)

# Interfejs użytkownika
click_button_frame = tk.Frame(root)
click_button_frame.pack(padx=10, pady=10)
click_button_frame.columnconfigure(0, weight=1)

# Załaduj obrazek i zmień jego rozmiar
image = Image.open("dot.png")
image = image.resize((300, 300), Image.ANTIALIAS)
dot_image = ImageTk.PhotoImage(image)

# Utwórz przycisk obrazka
click_button = tk.Button(click_button_frame, image=dot_image, command=click, relief="flat", borderwidth=0)
click_button.image = dot_image
click_button.pack()

# Label na punkty
points_label = tk.Label(click_button_frame, text="Points: 0", font=("Arial", 24, "bold"))
points_label.pack(pady=(0, 10))

clicker_label = tk.Label(root, text="Click Power: 1", font=("Arial", 14))
clicker_label.pack(padx=10, pady=10, anchor="e")

auto_clicker_label = tk.Label(root, text="Auto Clicker Power: 1\nCost: 10", font=("Arial", 14))
auto_clicker_label.pack(padx=10, pady=10, anchor="e")

buy_auto_clicker_button = tk.Button(root, text="Buy Auto Clicker", command=buy_auto_clicker, font=("Arial", 14))
buy_auto_clicker_button.pack(padx=10, pady=10, anchor="e")

# Usunięcie tła etykiety "upgrade_label"
upgrade_label = tk.Label(root, text=f"Upgrade Click Power\nCost: {click_power_cost}", font=("Arial", 14))
upgrade_label.pack(padx=10, pady=10, anchor="e")

upgrade_button = tk.Button(root, text="Upgrade Click Power", command=upgrade_click_power, font=("Arial", 14))
upgrade_button.pack(padx=10, pady=10, anchor="e")

save_button = tk.Button(root, text="Save Game", command=save_game, font=("Arial", 14))
save_button.pack(padx=10, pady=10, anchor="e")

load_button = tk.Button(root, text="Load Game", command=load_game, font=("Arial", 14))
load_button.pack(padx=10, pady=10, anchor="e")

# Przycisk "Settings"
settings_button = tk.Button(root, text="Settings", command=open_settings_window, font=("Arial", 14))
settings_button.pack(padx=10, pady=10, anchor="e")

# Rozpocznij automatyczne klikanie
auto_click()

# Wczytaj zapisaną grę (jeśli istnieje)
load_game()

# Aktualizuj wygląd okna na podstawie wyboru trybu
update_theme()

# Umożliw skalowanie okna
root.resizable(True, True)

# Obsługa klikania klawiszem Spacja
def space_click(event):
    click()
root.bind("<space>", space_click)

# Wycentruj okno na ekranie
root.update_idletasks()
root.geometry(f"{root.winfo_width()}x{root.winfo_height()}+{int((root.winfo_screenwidth() - root.winfo_width()) / 2)}+{int((root.winfo_screenheight() - root.winfo_height()) / 2)}")

root.mainloop()
